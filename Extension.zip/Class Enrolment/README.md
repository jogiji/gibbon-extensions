# module-classEnrolment
A simple module for allowing parents to enrol their children in classes, with no appoval required.
