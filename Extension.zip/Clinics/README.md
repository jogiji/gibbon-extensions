# module-clinics
Allows a school to adminsiter and run academic clinics, with some students assigned to clinics based on departmental needs, and others signing up themselves.

To import clinics take clinic.yml from /modules/Clinics/imports and move it to /resources/imports, and then check Admin > School Admin > Import From File in the Gibbon interface.
