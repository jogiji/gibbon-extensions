<?php
/*
Gibbon: Course Selection & Timetabling Engine
Copyright (C) 2017, Sandra Kuipers
*/

/**
 * Sets version information
 */
$moduleVersion="1.2.08" ;
$coreVersion = '23.0.00';
