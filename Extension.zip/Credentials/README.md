module-credentials
==================

Credentials is a module for storing student login details, and making them available via the Student profile. The app is aimed at helping teachers of young students retrieve forgotten usernames and passwords for the various systems they used. IT IS NOT DESIGNED FOR STORAGE OF IMPORTANT PASSWORDS PROTECTING SENSITIVE DATA.
