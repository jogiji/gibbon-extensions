module-freeLearning
===================

Free Learning is a module which enables a student-focused and student-driven pedagogy that goes by the same name as the module. Read more about Free Learning at http://rossparker.org/free-learning.
